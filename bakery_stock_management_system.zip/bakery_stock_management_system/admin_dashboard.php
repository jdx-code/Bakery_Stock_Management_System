<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");      
  }
 
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<title> ADMIN DASHBOARD</title>
</head>

<body>
<div id="container">
		<div id="mainpic">
        	<h1>The Bakery<span class="off">Store</span></h1>           
        </div>   
        
        <div id="menu">
        	<ul>
            	 <!-- <li class="menuitem"><a href="customers.php"> CUSTOMERS</a></li> -->
                <li class="menuitem"><a href="categories.php"> CATEGORIES</a></li>
                <li class="menuitem"><a href="products.php">PRODUCTS</a></li>
                <li class="menuitem"><a href="products_quan.php">QUANTITY</a></li>
                <li class="menuitem"><a href="sales.php">SALES</a></li>
                <li class="menuitem"><a href="logout.php">LOGOUT</a></li>                
            </ul>
        </div>
        
		<div id="content">
             <?php echo "WELCOME ".$_SESSION["username"]. ", THIS IS YOUR ADMIN DASHBOARD :)";?>
      </div>
   </div>
</body>
</html>