<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");
  }
  require_once 'connect.php';
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<title> ADMIN DASHBOARD</title>
</head>

<body>
<div id="container">
    <div id="mainpic">
          <h1>The Bakery<span class="off">Store</span></h1>            
        </div>   
        
        <div id="menu">
          <ul>
                <li class="menuitem"><a href="categories.php"> CATEGORIES</a></li>
                <li class="menuitem"><a href="products.php">PRODUCTS</a></li>
                <li class="menuitem"><a href="products_quan.php">QUANTITY</a></li>
                <li class="menuitem"><a href="sales.php">SALES</a></li>
                <li class="menuitem"><a href="logout.php">LOGOUT</a></li>                
            </ul>
        </div>
        
    <div id="content">

      
    <form name="product_form" action="add_products.php" method="post">
    PRODUCT NAME : 
    <input type="text" name="prod_name" value="">
    CATEGORY : 
    <select name="prod_cat">
     <option value="" selected disabled>SELECT CATEGORY</option>
      <?php
        $sql   = "SELECT * FROM category";
        $result = mysqli_query($conn,$sql);
        while($row = mysqli_fetch_array($result)){
          echo '<option value='.$row['cat_id'].'>'.$row['cat_name'].'</option>';
        }
      ?>
    </select>
      BARCODE : 
    <input type="text" name="prod_barcode" value=""><br>
     PRICE : 
    <input type="text" name="prod_price" value="">
      PRODUCT DESC : 
    <input type="text" name="prod_desc" value="">
    <input type="submit" name="subm" value="CLICK TO ADD">
  </form>
  <hr>

  <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Product ID</th>
      <th scope="col">Product Name</th>
      <th scope="col">Product Barcode</th>
      <th scope="col">Product Description</th>
      <th scope="col">Product Price</th>
      <th scope="col">Added On </th>
      <th scope="col">Category</th>
    </tr>
  </thead>

  <?php
    $sql   = "SELECT * FROM product, category WHERE product.cat_id = category.cat_id";
    $result = mysqli_query($conn,$sql);
    while($row = mysqli_fetch_array($result)){
  ?>
  <tbody>
    <tr>
      <td>
        <?php
          echo $row['prod_id'];
        ?>
      </td>
      <td>
        <?php
          echo $row['prod_name'];
        ?>
      </td>
      <td>
        <?php
          echo $row['prod_barcode'];
        ?>
      </td>
      <td>
        <?php
          echo $row['prod_desc'];
        ?>
      </td>
      <td>
        <?php
          echo $row['prod_price'];
        ?>
      </td>
      <td>
        <?php
          echo $row['date_added'];
        ?>
      </td>
      <td>
        <?php
          echo $row['cat_name'];
        ?>
      </td>

       <td>
        <a type="button" class="btn btn-danger" href="del_prod.php?prod_id=<?php echo $row['prod_id'];?>">DELETE</a>
       
      </td>

      <td>
        
          <a type="button" class="btn btn-danger" href="up_prod.php?prod_id=<?php echo $row['prod_id'];?>">UPDATE</a>
       
      </td>
      
        <?php
        }
        ?>
    </tr>

  </tbody>
  </table>
            
      </div>
   </div>
</body>
</html>