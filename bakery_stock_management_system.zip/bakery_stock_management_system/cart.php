<?php
	session_start();
	  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");      
  	}
 	require_once 'connect.php';
	if(isset($_SESSION["refresh"]))
	{
		if(!isset($_SESSION["cnt"]))
			$_SESSION["cnt"]=1;

		$cnt = $_SESSION["cnt"];
		$duplicate=1;
		for($i=1;$i<$cnt;$i++)
			if($_POST["pid"]==$_SESSION["pid$i"])
			{
				$duplicate=0;
				$_SESSION["qty$i"]+=$_POST["qty"];
				break;
			}
		if($duplicate==1){
			foreach($_POST as $var=>$val)
				$_SESSION["$var$cnt"] = $val;

			$_SESSION["cnt"]++;	
		}		
		unset($_SESSION["refresh"]);
	}	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<title> ADMIN DASHBOARD</title>
</head>

<body>
<div id="container">
    	<div id="mainpic">
          <h1>The Bakery<span class="off">Store</span></h1>
            <h2><a href="logout.php">LOGOUT</a></h2>
        </div>   
        
        <div id="menu">
          	<ul>
              <li class="menuitem"><a href="customers.php"> CUSTOMERS</a></li>
                <li class="menuitem"><a href="categories.php"> CATEGORIES</a></li>
                <li class="menuitem"><a href="products.php">PRODUCTS</a></li>
                <li class="menuitem"><a href="products_quan.php">QUANTITY</a></li>
                <li class="menuitem"><a href="sales.php">SALES</a></li>
                <li class="menuitem"><a href="manage_users.php">MANAGE USERS</a></li>                
            </ul>
        </div>
        
    <div id="content">
		<form id="form1" name="form1" method="post" action="billing.php">
		<table width="600" border="1" align="center" cellpadding="3" cellspacing="3">
		<tr>
			<!-- <td>
				&nbsp;
			</td> -->
			<td align="center">
				Sl. No.
			</td>			
			<td align="center">
				Product Name
			</td>
			<td align="center">
				Quantity
			</td>			
			<td align="center">
				Unit Price
			</td>			
		</tr>
		<?php
		$srno = 0;
		$gtot = 0;
		for($i=1;$i<$_SESSION["cnt"];$i++)
		{
			$srno++;
			$tot=$_SESSION["qty$i"] * $_SESSION["price$i"];
			$gtot+=$tot;
			// $sql   = "SELECT * FROM product WHERE prod_name = '".$_SESSION["pid$i"]."'";
			// $result = mysqli_query($conn,$sql);
		 //    while($row = mysqli_fetch_array($result)){
		?>
		<tr>
			<!-- <td>
				<input type="checkbox" name="check[]" id="check[]">
			</td> -->
			<td align="center"><?=$srno?></td>		
			<input type="hidden" name="pid[]" id="pid" value="<?=$_SESSION["pid$i"]?>">
			<?php
				$sql = "SELECT * FROM product, stock WHERE product.prod_id = stock.prod_id AND product.prod_id = '".$_SESSION["pid$i"]."'";
				$result = mysqli_query($conn,$sql);
			 		while($row = mysqli_fetch_array($result)){
		 	?>
		 	<td align="center"><input type="text" name="prod_name[]" id="prod_name" value="<?=$row["prod_name"]?>"></td>
		 	
			<td align="center"><input type="text" name="qty[]" id="qty" size="3" value="<?=$_SESSION["qty$i"]?>">
			</td>			
		
			<?php
		 		}
		 	?>
			<td align="center"><input type="text" name="price[]" id="price" size="3" value="<?=$_SESSION["price$i"]?>"></td>
								
			</td>
		</tr>			
		<?php			
			}
		?>
		<tr>
			<!-- <td colspan="2">
				<input type="submit" name="dc" id="dc" value="Delete Checked">
			</td> -->
			<td colspan="3" align="center"><h3>Grand Total</h3></td>
			<td colspan="3" align="center">
				<h3>
				<input type="text" name="gtot" id="gtot" size="3" value="<?=$gtot;?>" readonly>
				</h3>
			</td>
			<!-- <td colspan="3" align="center"><h3><?=$gtot;?></h3></td> -->
			<!-- <td>&nbsp;</td> -->
		</tr>	
		<tr>			
			<td colspan="4" align="right">
				<h3><a href="sales.php">Continue Shopping</a></h3>
			</td>				
		</tr>	
		</table>
		<table>
			
		</table>
		<table width="600" border="1" align="center" cellpadding="3" cellspacing="3">
		<tr>
			<td colspan="2" align="center">
				Customer Phone : <input type="text" name="cust_ph" value="">
			</td>
			<td colspan="2" align="center">
				Payment Mode : 
				<select name="pay_mode">
					<option value="" selected disabled>Select Mode of Payment</option>
					<option value="cash">Cash</option>
					<option value="card">Card</option>
					<option value="credit">Credit</option>
				</select>
			</td>		
			<td colspan="3" align="center">
				<input type="submit" name="submitBtn" value="Proceed to Payment">
			</td>
		</tr>
		</table>
	</form>    
    </div>
   </div>
</body>
</html>