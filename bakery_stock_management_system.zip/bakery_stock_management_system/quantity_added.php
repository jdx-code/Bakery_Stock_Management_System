<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");      
  }
  require_once 'connect.php';

  $prod_id 	  = $_POST['prod_id'];
  $quantity   = $_POST['quantity'];
  $prod_units = $_POST['prod_units'];  
  $entry_date = date('d/m/Y');
  $user_id	  = $_SESSION["user_id"];

  $sql   = "SELECT * FROM stock WHERE prod_id ='$prod_id'";
  $result = mysqli_query($conn,$sql);
  $count  = mysqli_num_rows($result);
  $row    = mysqli_fetch_array($result);
  if($count>=1){
    $sql = "UPDATE stock SET total_quantity = '$row[total_quantity]' + '$quantity', entry_date = '$entry_date', user_id = '$user_id' WHERE prod_id = '$prod_id'";
    $query = mysqli_query($conn,$sql);
  }
  else{
    $sql = "INSERT INTO stock (id,prod_id,total_quantity,unit_id,entry_date,user_id) VALUES (DEFAULT,'$prod_id','$quantity','$prod_units','$entry_date','$user_id')";
    $query = mysqli_query($conn,$sql);
  }
  
?>