<?php
  require_once 'connect.php';

  $cat_name = $_POST['cat_name'];
  $cat_status = $_POST['cat_status'];
  $date_aded = date('d/m/Y h:i:s', time());
  
 
  $sql   = "INSERT INTO category (cat_id,cat_name,date_added,status) VALUES (DEFAULT,'$cat_name','$date_aded','$cat_status')";
  $query = mysqli_query($conn,$sql);
?>