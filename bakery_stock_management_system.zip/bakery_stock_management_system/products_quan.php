<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");
  }
  require_once 'connect.php';
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<title> ADMIN DASHBOARD</title>
</head>

<body>
<div id="container">
    <div id="mainpic">
          <h1>The Bakery<span class="off">Store</span></h1>            
        </div>   
        
        <div id="menu">
          <ul>
                <li class="menuitem"><a href="categories.php"> CATEGORIES</a></li>
                <li class="menuitem"><a href="products.php">PRODUCTS</a></li>
                <li class="menuitem"><a href="products_quan.php">QUANTITY</a></li>
                <li class="menuitem"><a href="sales.php">SALES</a></li>
                <li class="menuitem"><a href="logout.php">LOGOUT</a></li>                
            </ul>
        </div>
        
    <div id="content">

      <form name="product_form" action="add_products.php" method="post">
      PRODUCT NAME : 
      <input type="text" name="prod_name" value="">
      CATEGORY : 
      <select name="prod_cat">
        <option value="" selected disabled>SELECT CATEGORY</option>
          <?php
            $sql   = "SELECT * FROM category";
            $result = mysqli_query($conn,$sql);
            while($row = mysqli_fetch_array($result)){
              echo '<option value='.$row['cat_id'].'>'.$row['cat_name'].'</option>';
            }
          ?>
      </select>
      BARCODE : 
      <input type="text" name="prod_barcode" value=""><br>
      PRICE : 
      <input type="text" name="prod_price" value="">
      PRODUCT DESC : 
      <input type="text" name="prod_desc" value="">
      <input type="submit" name="subm" value="CLICK TO ADD">
    </form>
    <hr>

    <form name="quantity_form" action="quantity_added.php" method="post">
      <table class="table table-striped">
      <thead>
        <tr>    
          <th scope="col">Product</th>
          <th scope="col">Quantity</th> 
          <th scope="col">Unit</th>  
        </tr>
      </thead>

      <tbody>
        <tr>
          <td>
            <select name="prod_id">
              <option value="" selected disabled>SELECT</option>     
                <?php
                  $sql = "SELECT * FROM product, category WHERE product.cat_id = category.cat_id ";
                  $result = mysqli_query($conn,$sql);
                  while($row = mysqli_fetch_array($result)){
                     echo '<option value='.$row['prod_id'].'>'.$row['prod_name'].'</option>';
                  }
                ?>
              </option>
            </select>     
          </td>
          <td>
            <select name="quantity">
              <option value="" selected disabled>SELECT</option>     
                <?php
                  for($i=1;$i<=50;$i++)
                  {
                     echo '<option value='.$i.'>'.$i.'</option>';
                  }
                ?>
              </option>
            </select>
          </td>
          <td>
            <select name="prod_units">
              <option value="" selected disabled>SELECT</option>
                <?php
                  $sql = "SELECT * FROM product_units";
                  $result = mysqli_query($conn,$sql);
                  while($row = mysqli_fetch_array($result)){
                     echo '<option value='.$row['id'].'>'.$row['unit_name'].'</option>';
                  }
                ?>
              </option>
            </select>
          </td> 
          <td>
            <input type="submit" name="submitBtn" value="Add To Shop">
          </td>          
        </tr>      
      </tbody>
      </table>
    </form>
        
    </div>
   </div>
</body>
</html>
