<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");
  }
  require_once 'connect.php';
  $cat_id = $_GET['cat_id'];
?>

<form name="up_cus_form" action="up_cat_submit.php" method="post">
  <table class="table table-striped">
    <thead>
      <tr>
        <!-- <th scope="col">Category ID</th> -->
        <th scope="col">Category Name</th>
        <!-- <th scope="col">Added On</th -->        
        <th scope="col">Status</th>
      </tr>
    </thead>

    <?php
      $sql   = "SELECT * FROM category where cat_id = '$cat_id'";
      $result = mysqli_query($conn,$sql);
      while($row = mysqli_fetch_array($result)){
    ?>
    
    <tbody>
      <tr> 
        <td>
          	<input type="text" name="cat_name" value="<?php echo $row['cat_name'];?>">
        </td> 
        <td>
        	<input type="text" name="status" value="<?php echo $row['status'];?>">
        </td>         
        	<input type="hidden" name="cat_id" value="<?php echo $row['cat_id'];?>">
        <td>
          	<input type="submit" name="sub" value"UPDATE">
        </td>
      </tr>
    </tbody>
    <?php
     }
    ?>    
  </table>
</form>

