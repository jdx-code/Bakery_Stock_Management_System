<?php
	session_start();
	  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");      
  	}
	require_once 'connect.php';
	$_SESSION["refresh"]="no";
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<title> ADMIN DASHBOARD</title>
</head>

<body>
<div id="container">
    <div id="mainpic">
          <h1>The Bakery<span class="off">Store</span></h1>            
        </div>   
        
        <div id="menu">
          <ul>              
                <li class="menuitem"><a href="categories.php"> CATEGORIES</a></li>
                <li class="menuitem"><a href="products.php">PRODUCTS</a></li>
                <li class="menuitem"><a href="products_quan.php">QUANTITY</a></li>
                <li class="menuitem"><a href="sales.php">SALES</a></li>
                <li class="menuitem"><a href="logout.php">LOGOUT</a></li>                
            </ul>
        </div>
        
    <div id="content">
	Sales Form
	<hr>
	<form name="sales_form" action="cart.php" method="post">
	  	<table width="250" border="1" align="center" cellpadding="3" cellspacing="3">
			

			<tr>
				<th scope="row">Product </th>
				<td width="73%"><select onChange="getquantity(this.value);"  name="pid" id="pid" class="form-control" >
					<option value="">Select</option>
					<?php $query =mysqli_query($conn,"SELECT * FROM product, stock WHERE product.prod_id = stock.prod_id AND stock.total_quantity>=1");
					while($row=mysqli_fetch_array($query))
					{ ?>
					<option value="<?php echo $row['prod_id'];?>"><?php echo $row['prod_name'];?></option>
					<?php
					}
					?>
					</select>
				</td>
			</tr>
			<tr>
				<th scope="row">Quantity </th>
				<td><select name="qty" id="quantity-list" class="form-control">
					<option value="">Select</option>
					</select>
				</td>
			</tr>

			<tr>
				<th scope="row">Price </th>				
				<td>
					<input type="" name="price" id="price">
				</td>
			</tr>			
			<tr>
				<td colspan="2" align="center">
					<input type="submit" value="Add to Cart">
				</td>			
			</tr>  	
	</form>          
   </div>


   <script>
		function getquantity(val) {
		$.ajax({
		type: "POST",
		url: "get_quantity.php",
		data:'pid='+val,
		success: function(data){
		$("#quantity-list").html(data);
		}
		});
		}
   </script>
</body>
</html>

