<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");
  }
  require_once 'connect.php';
  $prod_id = $_GET['prod_id'];
  $sql     = "DELETE FROM product where prod_id = '$prod_id'";
  $query   = mysqli_query($conn,$sql);
  header('Location: products.php');
?>