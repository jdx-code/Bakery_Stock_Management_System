<?php
	session_start();
	  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");      
  	}
	require_once 'connect.php';
	$_SESSION["refresh"]="no";
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<title> ADMIN DASHBOARD</title>
</head>

<body>
<div id="container">
    <div id="mainpic">
          <h1>The Bakery<span class="off">Store</span></h1>            
        </div>   
        
        <div id="menu">
          <ul>              
                <li class="menuitem"><a href="categories.php"> CATEGORIES</a></li>
                <li class="menuitem"><a href="products.php">PRODUCTS</a></li>
                <li class="menuitem"><a href="products_quan.php">QUANTITY</a></li>
                <li class="menuitem"><a href="sales.php">SALES</a></li>
                <li class="menuitem"><a href="logout.php">LOGOUT</a></li>                
            </ul>
        </div>
        
    <div id="content">
	<table class="table table-striped">
		<thead>
		    <tr>
		      <th scope="col">Sale ID</th>
		      <th scope="col">Customer Phone</th>
		      <th scope="col">Product Name</th>
		      <th scope="col">Quantity</th>
		      <th scope="col">Total Amount</th>
		      <th scope="col">Payment Mode</th>
		      <th scope="col">Date of Sale </th>		      
		    </tr>
		</thead>

		  <?php
		    $sql   = "SELECT * FROM sales ORDER BY sales_id DESC LIMIT 1;";
		    $result = mysqli_query($conn,$sql);
		    while($row = mysqli_fetch_array($result)){
		  ?>
		<tbody>
		    <tr>
		      <td>
		        <?php
		          echo $row['sales_id'];
		        ?>
		      </td>
		      <td>
		        <?php
		          echo $row['customer_phone'];
		        ?>
		      </td>
		      <td>
		        <?php
		          echo $row['prod_name'];
		        ?>
		      </td>
		      <td>
		        <?php
		          echo $row['quantity_taken'];
		        ?>
		      </td>
		      <td>
		        <?php
		          echo $row['total_amount'];
		        ?>
		      </td>
		      <td>
		        <?php
		          echo $row['payment_mode'];
		        ?>
		      </td>
		      <td>
		        <?php
		          echo $row['date_of_sale'];
		        ?>
		      </td>
		      
		        <?php
		        }
		        ?>
		      </tr>

		    </tbody>
	</table>
	<br><br><br><br><br>
	<a href="admin_dashboard.php">Go to Main Page</a>      
   </div>

</body>
</html>

