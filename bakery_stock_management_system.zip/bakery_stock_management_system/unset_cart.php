<?php
session_start();
unset($_SESSION["cnt"]);
header("Location:admin_dashboard.php");
?>