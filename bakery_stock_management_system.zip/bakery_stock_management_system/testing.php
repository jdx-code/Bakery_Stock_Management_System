<form name="insert" action="" method="post">
<table width="100%" height="117"  border="0">
<tr>
<th width="27%" height="63" scope="row">Sate :</th>
<td width="73%"><select onChange="getdistrict(this.value);"  name="state" id="state" class="form-control" >
<option value="">Select</option>
<?php $query =mysqli_query($con,"SELECT * FROM state");
while($row=mysqli_fetch_array($query))
{ ?>
<option value="<?php echo $row['StCode'];?>"><?php echo $row['StateName'];?></option>
<?php
}
?>
</select></td>
</tr>
<tr>
<th scope="row">District :</th>
<td><select name="district" id="district-list" class="form-control">
<option value="">Select</option>
</select></td>
</tr>
</table>
</form>

<------------------------------------------------------------------->
Getting States using jQuery AJAX
This script contains function that will be called on changing state dropdown values. It will send AJAX request to a PHP page to get corresponding district dropdown options.

<script>
function getdistrict(val) {
$.ajax({
type: "POST",
url: "get_district.php",
data:'state_id='+val,
success: function(data){
$("#district-list").html(data);
}
});
}
</script>

<------------------------------------------------------------------->
Read State Database using PHP
This PHP code connects database to retrieve district table values based on the country id passed by jQuery AJAX call.

<?php
require_once("config.php");
if(!empty($_POST["state_id"]))
{
$query =mysqli_query($con,"SELECT * FROM district WHERE StCode = '" . $_POST["state_id"] . "'");
?>
<option value="">Select District</option>
<?php
while($row=mysqli_fetch_array($query))
{
?>
<option value="<?php echo $row["DistrictName"]; ?>"><?php echo $row["DistrictName"]; ?></option>
<?php
}
}
?>

For Localhost create a database with name demos and import the sql file available inside download package.
-----------------------------------------
<select name="pid" id="pid">
  <option value="" selected disabled>>>>Select an Item<<<</option>     
    <?php
      $sql = "SELECT * FROM product, stock WHERE product.prod_id = stock.prod_id AND stock.total_quantity>=1";
      $result = mysqli_query($conn,$sql);
      while($row = mysqli_fetch_array($result)){
         echo '<option value='.$row['prod_id'].'>'.$row['prod_name'].'</option>';
      }
    ?>
  </option>
</select>