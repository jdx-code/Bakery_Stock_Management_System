<?php
 $hostname="localhost";
 $username="root";
 $database="db_bakery_stock";
 $password="";

 $conn = mysqli_connect($hostname,$username,$password,$database);
 if(!$conn){
 die("could not connect database...");
 }
?>
