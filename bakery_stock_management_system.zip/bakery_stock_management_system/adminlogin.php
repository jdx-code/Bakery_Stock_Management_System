<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<title>ADMIN LOGIN PAGE</title>
</head>

<body>
<div id="container">
		<div id="mainpic">
        	<h1>The Bakery<span class="off">Store</span></h1>
            <h2><a href="adminlogin.php">Admin Login</a></h2>
        </div>   
        
        <div id="menu">
        	<ul>
            	<li class="menuitem"><a href="#">Home</a></li>
                <li class="menuitem"><a href="#">About</a></li>
                <li class="menuitem"><a href="#">Products</a></li>
                <li class="menuitem"><a href="#">Services</a></li>
                <li class="menuitem"><a href="#">Services</a></li>
                <li class="menuitem"><a href="#">Contact</a></li>                
            </ul>
        </div>
        
		<div id="content">
        	<div>
	        	<form name="adminform" action="admincheck.php" method="post">
                    <table>
                        <tr>
                            <td>
                                Username :
                            </td>
                            <td>
                                <input type="text" name="username" value="">
                            </td>                            
                        </tr>
                        <tr>
                            <td>
                                Password : 
                            </td>
                            <td>
                                <input type="password" name="password" value="">
                            </td>                            
                        </tr>
                        <tr>                            
                            <td>
                                <input type="submit" name="subBtn" value="Login">
                            </td>                            
                        </tr>
                    </table>
				</form>	
        	</div>           
      </div>      
   </div>
</body>
</html>