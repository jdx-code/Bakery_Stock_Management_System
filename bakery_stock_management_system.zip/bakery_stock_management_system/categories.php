<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.php");
  }
  require_once 'connect.php';
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<title> ADMIN DASHBOARD</title>
</head>

<body>
<div id="container">
    <div id="mainpic">
          <h1>The Bakery<span class="off">Store</span></h1>            
        </div>   
        
        <div id="menu">
          <ul>              
                <li class="menuitem"><a href="categories.php"> CATEGORIES</a></li>
                <li class="menuitem"><a href="products.php">PRODUCTS</a></li>
                <li class="menuitem"><a href="products_quan.php">QUANTITY</a></li>
                <li class="menuitem"><a href="sales.php">SALES</a></li>
                <li class="menuitem"><a href="logout.php">LOGOUT</a></li>                
            </ul>
        </div>
        
    <div id="content">

      
    <form name="category_form" action="add_category.php" method="post">
      ADD NEW CATEGORY  : <input type="text" name="cat_name" value="">
      CATEGORY STATUS   : <select name="cat_status">
        <option value="" selected disabled>SELECT STATUS</option>
        <option value="active">ACTIVE</option>
        <option value="inactive">IN-ACTIVE</option>
        </select>
      <input type="submit" name="subm" value="CLICK TO ADD">
    </form>
    <hr>

    <table class="table table-striped">
    <thead>
      <tr>
        <!-- <th scope="col">Category ID</th> -->
        <th scope="col">Category Name</th>
        <th scope="col">Status</th>
      </tr>
    </thead>

    <?php
      $sql   = "SELECT * FROM category";
      $result = mysqli_query($conn,$sql);
      while($row = mysqli_fetch_array($result)){
    ?>
    <tbody>
      <tr>        
        <td>
          <?php
            echo $row['cat_name'];
          ?>
        </td>
        <td>
          <?php
            echo $row['status'];
          ?>
        </td>

         <td>
          <a type="button" class="btn btn-danger" href="del_cat.php?cat_id=<?php echo $row['cat_id'];?>">DELETE</a>
         
        </td>

        <td>
          
            <a type="button" class="btn btn-danger" href="up_cat.php?cat_id=<?php echo $row['cat_id'];?>">UPDATE</a>
         
        </td>
        
          <?php
          }
          ?>
      </tr>

    </tbody>
    </table>            
      </div>
   </div>
</body>
</html>



