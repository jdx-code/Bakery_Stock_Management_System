<?php
require_once("connect.php");
if(!empty($_POST["state_id"]))
{
$query =mysqli_query($conn,"SELECT * FROM stock WHERE prod_id = '" . $_POST["state_id"] . "'");
?>
<option value="">Select District</option>
<?php
while($row=mysqli_fetch_array($query))
{

for ($i = 1; $i <= $row['total_quantity']; $i++)
                      echo '<option value='.$i.'>'.$i.'</option>';

}
}
?>